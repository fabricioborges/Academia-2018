﻿CREATE TABLE [dbo].[TBCliente_Venda] (
    [Id_cliente_venda] INT IDENTITY (1, 1) NOT NULL,
    [Cliente_id]       INT NULL,
    [Venda_id]         INT NULL,
    PRIMARY KEY CLUSTERED ([Id_cliente_venda] ASC)
);

